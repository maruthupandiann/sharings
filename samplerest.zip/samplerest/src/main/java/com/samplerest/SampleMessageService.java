package com.samplerest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

@Path("/samplemessage")
public class SampleMessageService {

	@GET
	@Produces("text/html")
	public Response getMsg() {
 
		String result = "Welcome to rest service....";
 
		return Response.status(200).entity(result).build();
 
	}
 
}
